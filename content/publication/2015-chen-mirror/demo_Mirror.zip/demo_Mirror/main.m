clear,close all
dataName = 'viper';
sepName = 'separateViper';
%% parameter settings. Please see evaluation.m for detail
opts.kernel = 'linear'; % linear or rbf_chi_square
opts.method_opts.alpha = 0.5; % for linear kernel, it could be set as 0.5;
% for rbf-chi-square kernel, it could be set as 1e-2
opts.method_opts.dim = 70; % dimension of the baseline method KMFA
opts.method = 'KMFA2';
%% run experiments. CMC1 use the mirror representation; CMC0 use original features
opts.mirror = 1;
parfor i = 1 : 10
    CMC1(i,:) = evaluation(dataName,sepName,i,opts);
end
CMC1 = mean(CMC1,1);
disp('Rank1   Rank5   Rank10   Rank20')
CMC1 = CMC1*100;
fprintf('%2.2f,   %2.2f,   %2.2f,   %2.2f\n',CMC1(1),CMC1(5),CMC1(10),CMC1(20));

opts.mirror = 0;
parfor i = 1 : 10
    CMC0(i,:) = evaluation(dataName,sepName,i,opts);
end
CMC0 = mean(CMC0,1);
disp('Rank1   Rank5   Rank10   Rank20')
CMC0 = CMC0*100;
fprintf('%2.2f,   %2.2f,   %2.2f,   %2.2f\n',CMC0(1),CMC0(5),CMC0(10),CMC0(20));