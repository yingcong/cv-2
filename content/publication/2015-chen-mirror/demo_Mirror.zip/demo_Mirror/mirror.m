function [Xm1, Xm2] = mirror(X1,X2,r,beta,isKernel,K)
% transform the original feature to the mirror feature
% X1, X2: features of view 1 and view 2
% r and beta are defined in the paper
% isKernel: indicate if the features are kernel feature or not. 1: kernel
% feature; 0: original feature
% K_mat: the kernel matrix

dim = size(X1,1);
z = sqrt((1+r)^2+(1-r)^2);
R = (1 + r)/z * eye(dim);
M = (1 - r)/z * eye(dim);

% get mirror feature
Xaug1 = [R,M]' * X1;
Xaug2 = [M,R]' * X2;
if isKernel
    C = [K,-beta*K;-beta*K,K];
else
    C = [eye(dim),-beta*eye(dim);-beta*eye(dim),eye(dim)];
end
[P,Lambda] = eig(C);
Xm1 = Lambda^(-0.5)*P'*Xaug1;
Xm2 = Lambda^(-0.5)*P'*Xaug2;
end