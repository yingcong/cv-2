function [r,beta] = getDistSubspace(X1,X2)
% from the sample subspace of two views, automatically calculate r and
% beta, r and beta are defined in the paper.

G1 = princomp(X1','econ');
G2 = princomp(X2','econ');
cos_ = svd(G1'*G2);
sin2_ = (1 - cos_.^2);
r = mean(sin2_);
beta = mean(cos_) - 1e-3;
    
end