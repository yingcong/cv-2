run main.m for details.

@inproceedings{chen2015mirror,
  title={Mirror representation for modeling view-specific transform in person re-identification},
  author={Chen, Ying-Cong and Zheng, Wei-Shi and Lai, Jianhuang},
  booktitle={IJCAI},
  year={2015}
}