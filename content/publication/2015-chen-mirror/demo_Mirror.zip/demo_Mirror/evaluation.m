function CMC=evaluation(dataName,sepName,nthTrail,opts)
% nthTrail: the n.th trail
% dataName: path of the feature file
% sepName: path of the file that contain the separate information of the
% dataset
% opts.method: metric learning method,MFA is supported, which is a
% modificaton version of the implementation of Fei Xiong
% see http://robustsystems.coe.neu.edu/sites/robustsystems.coe.neu.edu/files/systems/projectpages/eccv14reid.html
% for detail
% opts.kernel: used kernel,linear, chi_square, rbf_chi_square
% are supported
% opts.mirror: indicate if mirror representaton is used
% refer to the paper Chen, Ying-Cong, Wei-Shi Zheng, and Jianhuang Lai. "Mirror representation 
% for modeling view-specific transform in person re-identification." Proc. IJCAI. 2015.
% opts.method_opts: options for other methods

% @inproceedings{chen2015mirror,
%   title={Mirror representation for modeling view-specific transform in person re-identification},
%   author={Chen, Ying-Cong and Zheng, Wei-Shi and Lai, Jianhuang},
%   booktitle={International Joint Conference on Artificial Intelligence},
%   pages={3402--3408},
%   year={2015}
% }
if ~isfield(opts,'method')
    opts.method = 'KMFA';
end
if ~isfield(opts,'kernel')
    opts.kernel = 'rbf_chi_square';
end
if ~isfield(opts,'mirror')
    opts.mirror = 1;
end
if ~isfield(opts,'mirror_opts')
    opts.mirror_opts = [];
end
if ~isfield(opts,'method_opts')
    opts.method_opts = [];
end
%% read data from files
load(dataName);
load(sepName);

% L1 normalization
Xview1 = L1_normalize(Xview1);
Xview2 = L1_normalize(Xview2);

Xtrain1=Xview1(:,trainInd1{nthTrail});
Xtrain2=Xview2(:,trainInd2{nthTrail});
groupTrain1=group1(trainInd1{nthTrail});groupTrain1=reshape(groupTrain1,numel(groupTrain1),1);
groupTrain2=group2(trainInd2{nthTrail});groupTrain2=reshape(groupTrain2,numel(groupTrain2),1);

Xtest1=Xview1(:,testInd1{nthTrail});
Xtest2=Xview2(:,testInd2{nthTrail});
groupTest1=group1(testInd1{nthTrail});groupTest1=reshape(groupTest1,numel(groupTest1),1);
groupTest2=group2(testInd2{nthTrail});groupTest2=reshape(groupTest2,numel(groupTest2),1);


%% training
% transform it to the kernel space
anchor = [Xtrain1,Xtrain2];
eval(['Func = @',opts.kernel,';']);
Ktrain1 = feval(Func,anchor,Xtrain1);
Ktrain2 = feval(Func,anchor,Xtrain2);
Ktest1 = feval(Func,anchor,Xtest1);
Ktest2 = feval(Func,anchor,Xtest2);
K_mat = [Ktrain1,Ktrain2];
if opts.mirror == 1
    if ~isfield(opts,'r') || ~isfield(opts,'beta')
        [r beta] = getDistSubspace(Xtrain1,Xtrain2);
    else
        r = opts.r;
        beta = opts.beta;
    end
    % transform to mirror representation
    [Ktrain1,Ktrain2] = mirror(Ktrain1,Ktrain2,r,beta,1,K_mat); 
    [Ktest1,Ktest2] = mirror(Ktest1,Ktest2,r,beta,1,K_mat);
else
    % for kernel methods, the ridge regularization is u^T K u, we still
    % decompose the K so that the ridge regularization could be u^T u. In
    % this way, we can use the same framework like mirror features.
    [Ktrain1,Ktrain2] = eigKernelReg(Ktrain1,Ktrain2,K_mat);
    [Ktest1,Ktest2] = eigKernelReg(Ktest1,Ktest2,K_mat);
end
eval(['P=',opts.method,'_class();']);
if ~isempty(strfind(opts.method,'KMFA'))
    opts.method_opts.Kdist = K_mat;
end
P.setPara(opts.method_opts);
P.train(Ktrain1,Ktrain2,groupTrain1,groupTrain2);
%% testing
distMat = P.calDistMat(Ktest1,Ktest2);
CMC = getCMC(distMat,groupTest1,groupTest2);
end
% normalize the samples via L1 norm
function Z = L1_normalize(X)
L1Norm = sum(abs(X));
L1Norm = repmat(L1Norm,[size(X,1),1]);
Z = X./L1Norm;
end
% rbf-chi-square kernel
function Z = rbf_chi_square(X,Y,varargin)
if numel(varargin) == 0
    scale = 1;
else
    scale = varargin{1};
end
nX = size(X,2);
nY = size(Y,2);
Z = zeros(nX,nY);
parfor i = 1 : nX
    X_i = repmat(X(:,i),[1,nY]);
    tmp1 = (X_i - Y).^2;
    tmp2 = X_i + Y + eps;
    tmp = tmp1 ./ tmp2;
    Z(i,:) = sum(tmp,1);
    Z(i,:) = exp(-Z(i,:)/scale);
end
end
% linear kernel
function Z = linear(X,Y)
Z = X' * Y;
end