function [Xm1,Xm2] = eigKernelReg(X1,X2,K)
% transforming the feature using this function let the kermel method could replace
% the regularization term K with I
[P,Lambda] = eig(K);
Xm1 = Lambda^(-0.5)*P'*X1;
Xm2 = Lambda^(-0.5)*P'*X2;
end