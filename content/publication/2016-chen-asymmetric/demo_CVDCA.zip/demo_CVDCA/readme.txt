run main.m for details

@inproceedings{chen2015CVDCA,
  title={An Asymmetric Distance Model for Cross-view Feature Mapping in Person Re-identification},
  author={Chen, Ying-Cong and Zheng, Wei-Shi and Yuen, Pong C. and Lai, Jianhuang},
  booktitle={IEEE Transactions on Circuits and Systems for Video Technology},
  year={2015}
}