% Kernel Cross-View Discriminant Component Analysis (KCVDCA)

% Key functions:

% training(this,X_gallery,X_probe,label_gallery,label_probe): train the
% model with training data. After training, U1 and U2 are filled
        % input: 
        % X_gallery and X_probe are training image features of gallery view
        % and probe view, one column corresponds to one image.
        % label_gallery and label_probe are the corresponding label of the
        % training images

% Z = calDistMat(this,X_gallery,X_probe): calculate the distance matrix
% between the gallery set and the probe set. Note that the gallery images in
% the training and testing phrase should be captured from the same view.
        % input:
        % X_gallery and X_probe are the testing gallery features and probe
        % features. One colomn corresponds to one image
        % output:
        % Z is a n_gallery * n_probe distance matrix.

% @inproceedings{chen2015CVDCA,
%   title={An Asymmetric Distance Model for Cross-view Feature Mapping in Person Re-identification},
%   author={Chen, Ying-Cong and Zheng, Wei-Shi and Yuen, Pong C. and Lai, Jianhuang},
%   booktitle={IEEE Transactions on Circuits and Systems for Video Technology},
%   year={2015}
% }
% Implemented by Ying-Cong Chen
% 2015/12/13

classdef KCVDCA < handle
    properties
        U1 = [];
        U2 = [];
        X = [];
        ridge_reg=0.3;
        csist_reg=0.15;
        Udim=190;
        kernel = 'chi_square';
        eta = 0.1;
        gamma = 0.1;
    end
    methods(Static)
        function Z = L1_normalize(X)
            L1Norm = sum(abs(X));
            L1Norm = repmat(L1Norm,[size(X,1),1]);
            Z = X./L1Norm;
        end
         function TrueTable = getTrueTable(label_gallery,label_probe)
            n_gal=size(label_gallery,1);
            n_prob=size(label_probe,1);
            TrueTable_train=repmat(label_gallery,[1 n_prob]);
            TrueTable_test=repmat(label_probe',[n_gal 1]);
            TrueTable=double(TrueTable_train==TrueTable_test);
         end       
        function Z = chi_square(X,Y)
            nX = size(X,2);
            nY = size(Y,2);
            Z = zeros(nX,nY);
            for i = 1 : nX
                X_i = repmat(X(:,i),[1,nY]);
                tmp1 = X_i .* Y;
                tmp2 = X_i + Y + eps;
                tmp = tmp1 ./ tmp2;
                Z(i,:) = sum(tmp,1);
            end
            Z = Z * 2;
        end
        function Z = rbf_chi_square(X,Y,varargin)
            if numel(varargin)==1
                r = varargin{1};
            else
                r = 1;
            end
            nX = size(X,2);
            nY = size(Y,2);
            Z = zeros(nX,nY);
            for i = 1 : nX
                X_i = repmat(X(:,i),[1,nY]);
                tmp1 = (X_i - Y).^2;
                tmp2 = X_i + Y + eps;
                tmp = tmp1 ./ tmp2;
                Z(i,:) = sum(tmp,1);
                Z(i,:) = exp(-Z(i,:)./r);
            end
        end  
    end
    methods
        % train the model
        % input: 
        % X_gallery and X_probe are training image features of gallery view
        % and probe view, one column corresponds to one image.
        % label_gallery and label_probe are the corresponding label of the
        % training images
        function training(this,X_gallery,X_probe,label_gallery,label_probe)
            X1_ = X_gallery;
            X2_ = X_probe;
            group1 = label_gallery;
            group2 = label_probe;
            %% normalize the X1 and X2
            X1 = this.L1_normalize(X1_);
            X2 = this.L1_normalize(X2_);
            X = [X1,X2];
            this.X = X;
            %% kernel
            eval(['F = @this.',this.kernel,';']);
            K1 = feval(F,X,X1);
            K2 = feval(F,X,X2);
            K12 = [K1,K2];

            %% generate the label matrix
            
            W_12_intraPerson = this.getTrueTable(group1,group2);
            W_12_betwPerson = 1 - W_12_intraPerson;
            pNum = sum(W_12_intraPerson(:));
            nNum = sum(W_12_betwPerson(:));
            W_12_betwPerson = W_12_betwPerson * pNum / nNum;
            W_12 = W_12_intraPerson - this.gamma * W_12_betwPerson;
            
            
            W_11 = this.getTrueTable(group1,group1);         
            W_11 = double(W_11');
            
            
            W_22 = this.getTrueTable(group2,group2);
            W_22 = double(W_22');
            

            %% Getting intermediate Parameters          
            D_12=diag(sum(W_12,2));
            D_21=diag(sum(W_12,1));
            dim=size(K1,1);
            
            
            D_11=diag(sum(W_11,2));
            
            D_22=diag(sum(W_22,2));
            
            H_12 = K1 * (D_12 + this.eta * D_11 - this.eta * W_11) * K1';
            H_21 = K2 * (D_21 + this.eta * D_22 - this.eta * W_22) * K2';
            G_1 = H_12 + this.ridge_reg * K12 + 1e-5*eye(dim);
            G_2 = H_21 + this.ridge_reg * K12 + 1e-5*eye(dim);
            R_12=K1*W_12*K2' + this.csist_reg * K12 ;
            R_21 = R_12';
            
            M_1 = K1 * K1' + this.ridge_reg * K12 + 1e-5*eye(dim);
            M_2 = K2 * K2' + this.ridge_reg * K12 + 1e-5*eye(dim);            
            
            dim=size(X1,1);
            %% Solving the problem
            R = [G_1,  -R_12 ;
                -R_21, G_2];               
            M = [M_1, zeros(size(R_12)) ; 
                zeros(size(R_21)) ,  M_2];
            [U,D] = eigs(R,M,this.Udim,'SM');
%             D = diag(D);
%             [~,idx] = sort(D,'ascend');
%             U = U(:,idx);
            p = size(U,1);
            for i = 1 : this.Udim
                this.U1 = [this.U1, U(1:p/2,i)];
                this.U2 = [this.U2, U(p/2+1:end,i)];
            end
            for i = 1 : this.Udim
                this.U1(:,i) = this.U1(:,i) / sqrt(this.U1(:,i)' * M_1 * this.U1(:,i));
                this.U2(:,i) = this.U2(:,i) / sqrt(this.U2(:,i)' * M_2 * this.U2(:,i));
            end
            this.U1 =  this.U1;
            this.U2 =  this.U2;
        end
        function [Y1,Y2] = project(this,X1,X2)
            X1 = this.L1_normalize(X1);
            X2 = this.L1_normalize(X2);
            eval(['F = @this.',this.kernel,';']);
            K1 = feval(F,this.X,X1);
            K2 = feval(F,this.X,X2);
            Y1 = this.U1'* K1;
            Y2 = this.U2'* K2;
        end
        % get the distance matrix of the testing images.
        % input:
        % X_gallery and X_probe are the testing gallery features and probe
        % features. One colomn corresponds to one image
        % output:
        % Z is a n_gallery * n_probe distance matrix.
        function Z = calDistMat(this,X_gallery,X_probe)
            [Y1,Y2] = this.project(X_gallery,X_probe);
            nGallery=size(Y1,2);
            nProbe=size(Y2,2);
            Z=zeros(nGallery,nProbe);
            for i=1:nGallery
                for j=1:nProbe
                    Z(i,j)=1-(Y1(:,i)'*Y2(:,j))/(norm(Y1(:,i)) * norm(Y2(:,j))); % using cosin measure
                end
            end
        end
    end
    
    
end