% Cross-View Discriminant Component Analysis (CVDCA)

% Key functions:

% training(this,X_gallery,X_probe,label_gallery,label_probe): train the
% model with training data. After training, U1 and U2 are filled
        % input: 
        % X_gallery and X_probe are training image features of gallery view
        % and probe view, one column corresponds to one image.
        % label_gallery and label_probe are the corresponding label of the
        % training images

% Z = calDistMat(this,X_gallery,X_probe): calculate the distance matrix
% between the gallery set and the probe set. Note that the gallery images in
% the training and testing phrase should be captured from the same view.
        % input:
        % X_gallery and X_probe are the testing gallery features and probe
        % features. One colomn corresponds to one image
        % output:
        % Z is a n_gallery * n_probe distance matrix.

% @inproceedings{chen2015CVDCA,
%   title={An Asymmetric Distance Model for Cross-view Feature Mapping in Person Re-identification},
%   author={Chen, Ying-Cong and Zheng, Wei-Shi and Yuen, Pong C. and Lai, Jianhuang},
%   booktitle={IEEE Transactions on Circuits and Systems for Video Technology},
%   year={2015}
% }
% Implemented by Ying-Cong Chen
% 2015/12/13
classdef CVDCA < handle
    properties
        U1 = []; % projection matrix of view 1 (gallery view)
        U2 = []; % projection matrix of view 2 (probe view)
        ridge_reg = 1e-3; % ridge regularization part. \gamma in the paper.
        csist_reg = 5e-4; % consistency regularization part. it is set as 0.5 * \gamma
        Udim=260; % dimension of the CVDCA
        eta = 0.1; % trade-off of the 
        gamma = 0.1;
    end
    methods(Static)
         function TrueTable = getTrueTable(label_gallery,label_probe)
            n_gal=size(label_gallery,1);
            n_prob=size(label_probe,1);
            TrueTable_train=repmat(label_gallery,[1 n_prob]);
            TrueTable_test=repmat(label_probe',[n_gal 1]);
            TrueTable=double(TrueTable_train==TrueTable_test);
        end       
    end
    methods
        % train the model
        % input: 
        % X_gallery and X_probe are training image features of gallery view
        % and probe view, one column corresponds to one image.
        % label_gallery and label_probe are the corresponding label of the
        % training images
        function training(this,X_gallery,X_probe,label_gallery,label_probe)
            X1_ = X_gallery;
            X2_ = X_probe;
            group1 = label_gallery;
            group2 = label_probe;
           % re-scale (normalize) the data metrices
            tr1=(trace(X1_*X1_'));
            tr2=(trace(X2_*X2_'));
            X1=X1_/sqrt(tr1);
            X2=X2_/sqrt(tr2);
          % dimensional reduction by PCA
            [coeff,~,~]=princomp([X1 X2]','econ');
            X1=coeff'*X1;
            X2=coeff'*X2;
            
            %% generate the label matrix
            
            W_12_intraPerson = this.getTrueTable(group1,group2);
            W_12_betwPerson = 1 - W_12_intraPerson;
            pNum = sum(W_12_intraPerson(:));
            nNum = sum(W_12_betwPerson(:));
            W_12_betwPerson = W_12_betwPerson * pNum / nNum;
            W_12 = W_12_intraPerson - this.gamma * W_12_betwPerson;
            
            
            W_11 = this.getTrueTable(group1,group1);         
            W_11 = double(W_11');
            
            
            W_22 = this.getTrueTable(group2,group2);
            W_22 = double(W_22');
            

            %% Getting intermediate Parameters          
            D_12=diag(sum(W_12,2));
            D_21=diag(sum(W_12,1));
            dim=size(X1,1);
            
            
            D_11=diag(sum(W_11,2));
            
            D_22=diag(sum(W_22,2));
            
            H_12 = X1 * (D_12 + this.eta * D_11 - this.eta * W_11) * X1';
            H_21 = X2 * (D_21 + this.eta * D_22 - this.eta * W_22) * X2';
            G_1 = H_12 + this.ridge_reg * eye(dim);
            G_2 = H_21 + this.ridge_reg * eye(dim);
            R_12=X1*W_12*X2' + this.csist_reg * eye(dim);
            R_21 = R_12';
            
            M_1 = X1 * X1' + this.ridge_reg * eye(dim);
            M_2 = X2 * X2' + this.ridge_reg * eye(dim);            
            
            dim=size(X1,1);
            %% Solving the problem
            R = [G_1,  -R_12 ;
                -R_21, G_2];               
            M = [M_1, zeros(size(R_12)) ; 
                zeros(size(R_21)) ,  M_2];
            [U,D] = eigs(R,M,this.Udim,'SM');
%             D = diag(D);
%             [~,idx] = sort(D,'ascend');
%             U = U(:,idx);
            p = size(U,1);
            for i = 1 : this.Udim
                this.U1 = [this.U1, U(1:p/2,i)];
                this.U2 = [this.U2, U(p/2+1:end,i)];
            end
            for i = 1 : this.Udim
                this.U1(:,i) = this.U1(:,i) / sqrt(this.U1(:,i)' * M_1 * this.U1(:,i));
                this.U2(:,i) = this.U2(:,i) / sqrt(this.U2(:,i)' * M_2 * this.U2(:,i));
            end
            this.U1 = coeff * this.U1;
            this.U2 = coeff * this.U2;
        end
        
        
        function [Y1,Y2] = project(this,X1,X2)
            Y1 = this.U1'* X1;
            Y2 = this.U2'* X2;
        end
        % get the distance matrix of the testing images.
        % input:
        % X_gallery and X_probe are the testing gallery features and probe
        % features. One colomn corresponds to one image
        % output:
        % Z is a n_gallery * n_probe distance matrix.
        function Z = calDistMat(this,X_gallery,X_probe)
            Y1 = this.U1'* X_gallery;
            Y2 = this.U2'* X_probe;
            nGallery=size(Y1,2);
            nProbe=size(Y2,2);
            Z=zeros(nGallery,nProbe);
            for i=1:nGallery
                for j=1:nProbe
                    Z(i,j)=1-(Y1(:,i)'*Y2(:,j))/(norm(Y1(:,i)) * norm(Y2(:,j))); % using cosin measure
                end
            end
        end
        
    end
    
    
end