function CMC=evaluation(dataName,methodName)
%% get training and testing samples
load(dataName);
[trainInd1,trainInd2,testInd1,testInd2] = separate(group1,group2); % separete the dataset.
Xview1Train=Xview1(:,trainInd1);
Xview2Train=Xview2(:,trainInd2);
groupTrain1=group1(trainInd1);groupTrain1=reshape(groupTrain1,numel(groupTrain1),1);
groupTrain2=group2(trainInd2);groupTrain2=reshape(groupTrain2,numel(groupTrain2),1);
Xview1Test=Xview1(:,testInd1);
Xview2Test=Xview2(:,testInd2);
groupTest1=group1(testInd1);groupTest1=reshape(groupTest1,numel(groupTest1),1);
groupTest2=group2(testInd2);groupTest2=reshape(groupTest2,numel(groupTest2),1);
%% train the model

eval(['model=',methodName,'();']);
model.training(Xview1Train,Xview2Train,groupTrain1,groupTrain2);

%% test the CMC
distMat = model.calDistMat(Xview1Test,Xview2Test);
CMC = getCMC(distMat,groupTest1,groupTest2);
end