clear,clc,close all
% name of the dataset. in viper.mat, Xview1 and Xview2 are features of the
% images captured from view 1 and view2. group1 and group2 are the
% corresponding labels.
dataset = 'viper'; 
method = 'KCVDCA'; % name of the method. CVDCA or KCVDCA
for i =1 : 10
    CMC(i,:) = evaluation(dataset,method);
end
CMC = mean(CMC,1);
disp('Rank1   Rank5   Rank10   Rank20')
CMC = CMC*100;
fprintf('%2.2f,   %2.2f,   %2.2f,   %2.2f\n',CMC(1),CMC(5),CMC(10),CMC(20));